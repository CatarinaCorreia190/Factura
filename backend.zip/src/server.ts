import app from "./http/app";

app.listen(3000);